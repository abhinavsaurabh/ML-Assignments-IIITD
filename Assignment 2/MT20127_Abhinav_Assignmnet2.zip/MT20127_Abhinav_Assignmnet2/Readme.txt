1. Ipynb contains all the jupytor files.
2. Contains Script py files which I have converted from jupytor files
3. ML Assignment 1 Report  contains all the graphs and explanations and analysis for all the questions.